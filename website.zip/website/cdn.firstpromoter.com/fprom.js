(function() {
  // Your code here
  console.log('FirstPromoter script loaded');
})()